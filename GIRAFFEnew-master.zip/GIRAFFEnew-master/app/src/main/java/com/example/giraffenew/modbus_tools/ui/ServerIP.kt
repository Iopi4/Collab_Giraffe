package com.example.giraffenew.modbus_tools.ui

import ModbusViewModel
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.giraffenew.R
import com.example.giraffenew.core.ui_kit.composable.button.BasicButtonGiraffe
import com.example.giraffenew.core.ui_kit.composable.text.BasicNameSettingParameterGiraffe
import com.example.giraffenew.core.ui_kit.composable.text.BasicTextFilledGiraffeDecimal
import com.example.giraffenew.core.ui_kit.composable.text.BasicValuesSettingsParameterGiraffe
import com.example.giraffenew.ui.theme.Burgundy_violet
import com.example.giraffenew.ui.theme.GIRAFFEnewTheme
import com.example.giraffenew.ui.theme.Orange


@Composable
fun ServerIP(
    modifier: Modifier = Modifier,
    viewModel: ModbusViewModel = androidx.lifecycle.viewmodel.compose.viewModel(),
) {
//Создаем поле в котором разделим экраны на две вертикальные области №1, №2.
    Row(
        modifier = Modifier.fillMaxSize()
    ) {


        //№.1 - Левая область для отображения Бокса - Данные порта)
        Column(
            modifier = Modifier
                .fillMaxSize()
                    .weight(2f)
                .padding(5.dp)
                .fillMaxSize()
                .border(
                    width = 3.dp, color = Orange, shape = RoundedCornerShape(5.dp)
                ), verticalArrangement = Arrangement.Top
        ) {
            BasicNameSettingParameterGiraffe(
                settingParameterId = R.string.ModbusTools_Text_Server_IP
            )

            BasicNameSettingParameterGiraffe(
                settingParameterId = R.string.ModbusTools_Text_Server_Port
            )

            BasicNameSettingParameterGiraffe(
                settingParameterId = R.string.ModbusTools_Text_Remote_Server_URL
            )

            // Кнгопка Connect
            BasicButtonGiraffe(
                modifier = Modifier,
                text = R.string.ModbusTools_Button_Connect,
                onClick = {viewModel.connectToServer()},
            ) {}

            // Кнгопка Disconnect
            BasicButtonGiraffe(
                modifier = Modifier,
                text = R.string.ModbusTools_Button_Disconnect,
                onClick = {viewModel.disconnectServer()},
            ) {}

        }


//№.2 - Правая область для настройки порта
        Column(
            modifier = Modifier
                .fillMaxSize()
                    .weight(3f)
                    .padding(5.dp)
                    .fillMaxSize()
                    .border(
                    width = 3.dp, color = Burgundy_violet, shape = RoundedCornerShape(5.dp)
                ), verticalArrangement = Arrangement.Top
        ) {

        //Ввод. Server_IP
            Box(
                modifier = Modifier.padding(start = 15.dp, end = 15.dp, top = 7.dp, bottom = 0.dp)
            ) {
                // Collect the state from StateFlow
                val ipAddress = viewModel.ipAddress.collectAsState()
                BasicTextFilledGiraffeDecimal(
                    placeholder = "192.168.1.88",
                    value = ipAddress.value,
                    onValueChange = { viewModel.updateIpAddress(it) },
                    modifier = Modifier,

                )
            }
            //Ввод. Server_Port
            Box(
                    modifier = Modifier.padding(start = 15.dp, end = 15.dp, top = 7.dp, bottom = 0.dp)
            ) {
            val port = viewModel.port.collectAsState()
                BasicTextFilledGiraffeDecimal(
                    placeholder = "502",
                    value = port.value.toString(),
                    onValueChange = { viewModel.updatePort(it.toIntOrNull() ?: 0) },
                    modifier = Modifier,

                )
            }

            //Ввод. Remote Server URL
            Box(
                    modifier = Modifier.padding(start = 15.dp, end = 15.dp, top = 7.dp, bottom = 0.dp)
            ) {
            val remoteServerUrl = viewModel.remoteServerUrl.collectAsState()
                BasicTextFilledGiraffeDecimal(
                    placeholder = "https://monitor.giraffecrane.ru",
                    value = remoteServerUrl.value,
                    onValueChange = { viewModel.updateRemoteServerUrl(it) },
                    modifier = Modifier,

                )
            }

            // Connection statusAdd commentMore actions
            Box(
                modifier = Modifier.padding(start = 15.dp, end = 15.dp, top = 7.dp, bottom = 0.dp)
            ) {
                val connectionStatus = viewModel.connectionStatus.collectAsState()
                val displayText =
                    if (connectionStatus.value == ModbusViewModel.ConnectionStatus.Connected) "Connected" else "Disconnected"
                BasicValuesSettingsParameterGiraffe(
                    modifier = Modifier.fillMaxWidth(),
                    valueParameterId = displayText
                )

            }

            // Отображение статуса удаленного сервера
            Box(
                modifier = Modifier
                    .padding(start = 15.dp, end = 15.dp, top = 7.dp, bottom = 0.dp)
                    .fillMaxWidth()
            ) {
                val remoteServerStatus = viewModel.remoteServerStatus.collectAsState()
                val displayText = when (remoteServerStatus.value) {
                    is ModbusViewModel.RemoteServerStatus.NotSent -> "Not Sent"
                    is ModbusViewModel.RemoteServerStatus.Sending -> "Sending..."
                    is ModbusViewModel.RemoteServerStatus.Success -> "Success"
                    is ModbusViewModel.RemoteServerStatus.Error -> "Error: ${(remoteServerStatus.value as ModbusViewModel.RemoteServerStatus.Error).message}"
                }
                BasicValuesSettingsParameterGiraffe(
                    modifier = Modifier.fillMaxWidth(),
                    valueParameterId = "Remote Server: $displayText"
                )
            }

        }



    }
}



@Preview
@Composable
fun ServerIPPreview(){
    GIRAFFEnewTheme(dynamicColor = false) {
        ServerIP(
        )
    }
}

package com.example.giraffenew.parameter_logger.presentation

import android.util.Log
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.giraffenew.data.entities.UIParameterLoggerConfiguration
import com.example.giraffenew.data.repositories.ModbusRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject
import kotlin.Int

@HiltViewModel
class ParameterLoggerViewModule @Inject constructor(
    private val modbusRepository: ModbusRepository
) : ViewModel() {

    private val _currentDateSettingMode = mutableStateOf("00.00.0000")
    val currentDateSettingMode: State<String> = _currentDateSettingMode

    private val _currentTimeSettingMode = mutableStateOf("00:00")
    val currentTimeSettingMode: State<String> = _currentTimeSettingMode

    private val _currentDateSBKBInstallation = mutableStateOf("00.00.0000")
    val currentDateSBKBInstallation: State<String> = _currentDateSBKBInstallation


    val addressParameterCrane = listOf( 33503, 33505, 33541, 33542, 33543, 33544, 283, 33546, 33547,
        33521, 33522, 33523, 33524, 33525, 33526, 33500, 33510, 33517, 33518, 33519,
        33561, 33562, 33563, 33564, 33565, 33566, 33556,
        35000, 35001, 35002, 35003, 35004, 35005)

    val addressCyclesOfWork = listOf(
        33580, 33581, 33582, 33583, 33584, 33585, 33586, 33587, 33588, 33589,
        33590, 33591, 33592, 33593, 33594, 33595, 33596, 33597, 33598, 33599,
        33600, 33601, 33620, 33621, 33622, 33623, 33624, 33625, 33626, 33627, 33628, 33629)

    private val allAddresses = (addressParameterCrane+addressCyclesOfWork).distinct()

    private val _state = mutableStateOf(ParameterLoggerState())
    val state: State<ParameterLoggerState> = _state

    private var dataCollectionJob: Job? = null


    /**
    2. В коллекторе потока registerCache, будем преобразовывать весь кэш в отфильтрованную карту (только наши адреса).
    Далее, мы можем сохранять предыдущую отфильтрованную карту и сравнивать с новой. Если они одинаковые, то ничего не делаем.
    Если изменилась, то вычисляем новое состояние и обновляем _state.
     */

    fun setActiveConfiguration() {
        modbusRepository.setActiveUiConfiguration(UIParameterLoggerConfiguration.NAME_PARAMETER_LOGGER)
        startDataCollection()
    }

    fun clearActiveConfiguration() {
        pauseDataCollection()
        modbusRepository.setActiveUiConfiguration(null)
    }
    // Запуск сбора данных
    fun startDataCollection() {
        dataCollectionJob?.cancel() // Всегда отменяем предыдущую job
        //if (dataCollectionJob?.isActive == true) return

        Log.d(
            "ParameterLoggerScreenVM",
            "Starting data collection for ${UIParameterLoggerConfiguration.NAME_PARAMETER_LOGGER}"
        )
        dataCollectionJob = viewModelScope.launch(Dispatchers.IO) {
            modbusRepository.getConfigurationFlow(UIParameterLoggerConfiguration.NAME_PARAMETER_LOGGER)
                .collect { cache ->
                    Log.d("ParameterLoggerViewModel", "Updating from cache, size: ${cache.size}")
                    // Обработка данных
                    try {
                        // Создаем отфильтрованную карту только для нужных адресов
                        val filteredCache = allAddresses.associate { addr ->
                            addr to cache[addr]?.value
                        }
                        _state.value = createParameterLoggerScreenState(filteredCache)
                    } catch (e: Exception) {
                        Log.e("ParameterLoggerScreenVM", "Data collection error", e)
                    }
                }
        }
    }


    // Приостановка сбора данных
    fun pauseDataCollection() {
        Log.d("ParameterLoggerVM", "Pausing data collection")
        dataCollectionJob?.cancel()
        dataCollectionJob = null
    }

    private fun createParameterLoggerScreenState(cache: Map<Int, Int?>): ParameterLoggerState{
        return ParameterLoggerState(
            сraneParameters = CraneParametersState(
                qNom        = cache[33503] ?: 0,
                craneLenght = safeDivideTens(cache[33505] ?: 0),
                rAP         = cache[33541] ?: 0,
                rAFIso      = cache[33542] ?: 0,
                rQF         = cache[33543] ?: 0,
                kP          = cache[33544] ?: 0,
                classOfUseC = cache[33545] ?: 0,
                rN1         = cache[33546] ?: 0,
                rN2         = cache[33547] ?: 0,
                settingModeYear     = cache[33521] ?: 0,
                settingModeMonth    = cache[33522] ?: 0,
                settingModeDay      = cache[33523] ?: 0,
                settingModeHour     = cache[33524] ?: 0,
                settingModeMinute   = cache[33525] ?: 0,
                settingModeSeconds  = cache[33526] ?: 0,
                hmiSBKBNo           = cache[33510] ?: 0,
                hmiCraneNo          = cache[33500] ?: 0,

                hmiSBKBInstallationDay= cache[33517] ?: 0,
                hmiSBKBInstallationMonth= cache[33518] ?: 0,
                hmiSBKBInstallationYear= cache[33519] ?: 0,

                hmiHoistOperatingHours  = safeDivideTens(cache[33561] ?: 0),
                hmiSlewOperatingHours   = safeDivideTens(cache[33562] ?: 0),
                hmiTrolleyOperatingHours    = safeDivideTens(cache[33563] ?: 0),
                hmiCraneOperatingHours      = safeDivideTens(cache[33564] ?: 0),
                hmiTotalCraneOperatingHours = safeDivideTens(cache[33565] ?: 0),
                hmiSBKBOperatingHours       = safeDivideTens(cache[33566] ?: 0),
                hmiHoleCraneHoursTO       = safeDivideTens(cache[33556] ?: 0),
            ),

            cyclesOfWorkParameters = CyclesOfWorkParametersState(
                arrRestA1MW1 = cache[33580] ?: 0,
                arrRestA1MW2 = cache[33581] ?: 0,
                arrRestA2MW1 = cache[33582] ?: 0,
                arrRestA2MW2 = cache[33583] ?: 0,
                arrRestA3MW1 = cache[33584] ?: 0,
                arrRestA3MW2 = cache[33585] ?: 0,
                arrRestA4MW1 = cache[33586] ?: 0,
                arrRestA4MW2 = cache[33587] ?: 0,
                arrRestA5MW1 = cache[33588] ?: 0,
                arrRestA5MW2 = cache[33589] ?: 0,
                arrRestA6MW1 = cache[33590] ?: 0,
                arrRestA6MW2 = cache[33591] ?: 0,
                arrRestA7MW1 = cache[33592] ?: 0,
                arrRestA7MW2 = cache[33593] ?: 0,
                arrRestA8MW1 = cache[33594] ?: 0,
                arrRestA8MW2 = cache[33595] ?: 0,
                arrRestA9MW1 = cache[33596] ?: 0,
                arrRestA9MW2 = cache[33597] ?: 0,
                arrRestA10MW1 = cache[33598] ?: 0,
                arrRestA10MW2 = cache[33599] ?: 0,
                arrRestA11MW1 = cache[33600] ?: 0,
                arrRestA11MW2 = cache[33601] ?: 0,

                rCycleHoistMW1 = cache[33620] ?: 0,
                rCycleHoistMW2 = cache[33621] ?: 0,
                rCycleSlewMW1 = cache[33622] ?: 0,
                rCycleSlewMW2 = cache[33623] ?: 0,
                rCycleTrolleyMW1 = cache[33624] ?: 0,
                rCycleTrolleyMW2 = cache[33625] ?: 0,
                rCycleCraneMW1 = cache[33626] ?: 0,
                rCycleCraneMW2 = cache[33627] ?: 0,
                rCycleHoleCraneMW1 = cache[33628] ?: 0,
                rCycleHoleCraneMW2 = cache[33629] ?: 0,
            ),
            savingAndLoadingSettings = SavingAndLoadingSettings(
                hmiReadSDcardStatus= cache[35000] ?: 0, //Статус SD-карты
                hmiReadVarSaveStatus= cache[35001] ?: 0, //Статус сохранения VAR-файла 0-Ожидание, 1- Завершено, 2- В процессе, 4-Ошибка.
                hmiReadVarSaveProcess = safeDivideTens(cache[35002] ?: 0), //Процес выполнения сохранения 0-100%
                hmiReadVarReadStatus= cache[35003] ?: 0, //Статус чтения VAR-файла 0-Ожидание, 1- Завершено, 2- В процессе, 4-Ошибка.
                hmiReadVarReadProcess = safeDivideTens(cache[35004] ?: 0), //Процес выполнения чтения 0-100%
                hmiReadVarSize = safeDivideHundred(cache[35005] ?: 0), //Объем VAR-файла
                )
        )
    }




    private fun safeDivide(value: Int?): Float {
        return (value ?: 0) / 1f
    }

    private fun safeDivideTens(value: Int?): Float {
        return (value ?: 0) / 10f
    }
    private fun safeDivideHundred(value: Int?): Float {
        return (value ?: 0) / 100f
    }

    data class ParameterLoggerState(
        val сraneParameters: CraneParametersState = CraneParametersState(),
        val cyclesOfWorkParameters: CyclesOfWorkParametersState = CyclesOfWorkParametersState(),
        val savingAndLoadingSettings: SavingAndLoadingSettings = SavingAndLoadingSettings(),
    )


    data class CraneParametersState(
        val qNom: Int=0, //Номинальная грузоподъемность в кг
        val craneLenght: Float=0f, //Длина стрелы крана
        val rAP: Int=0, //Паспортная группа режима работы
        val rAFIso: Int=0, //Фактическая группа режима работы по ИСО
        val rQF: Int=0, //Фактический класс нагружения
        val kP: Int=0, //Коэффициент нагружения Кр
        val classOfUseC: Int=0, //Класс использования С
        val rN1: Int=0, //текущее характеристическое число. Слово 1
        val rN2: Int=0, //текущее характеристическое число. Слово 2
        //Дата и время включения последнего режима наладки
        val settingModeYear: Int=0,
        val settingModeMonth: Int=0,
        val settingModeDay: Int=0,
        val settingModeHour: Int=0,
        val settingModeMinute: Int=0,
        val settingModeSeconds: Int=0,

        val hmiSBKBNo: Int=0, //Заводской номер СБКБ
        val hmiCraneNo: Int=0, //Заводской номер крана

        val hmiSBKBInstallationDay: Int=0, //День установки системы безопасности
        val hmiSBKBInstallationMonth: Int=0, //Месяц установки системы безопасности
        val hmiSBKBInstallationYear: Int=0, //Год установки системы безопасности

        //Моточасы
        val hmiHoistOperatingHours: Float=0f, //Моточасы механизма подъема
        val hmiSlewOperatingHours: Float=0f, //Моточасы механизма поворота
        val hmiTrolleyOperatingHours: Float=0f,//Моточасы механизма тележки
        val hmiCraneOperatingHours: Float=0f, //Моточасы механизма передвижения крана
        val hmiTotalCraneOperatingHours: Float=0f,//Общие моточасы крана
        val hmiSBKBOperatingHours: Float=0f, //Моточасы системы безопасности
        val hmiHoleCraneHoursTO: Float=0f, //Моточасы системы безопасности
    )
    data class CyclesOfWorkParametersState(
        val arrRestA1MW1: Int=0, //0-10% Количество циклов подъема в зависимости от веса груза
        val arrRestA1MW2: Int=0, //0-10% Количество циклов подъема в зависимости от веса груза
        val arrRestA2MW1: Int=0, //11-20% Количество циклов подъема в зависимости от веса груза
        val arrRestA2MW2: Int=0, //11-20% Количество циклов подъема в зависимости от веса груза
        val arrRestA3MW1: Int=0, //21-30% Количество циклов подъема в зависимости от веса груза
        val arrRestA3MW2: Int=0, //21-30% Количество циклов подъема в зависимости от веса груза
        val arrRestA4MW1: Int=0, //31-40% Количество циклов подъема в зависимости от веса груза
        val arrRestA4MW2: Int=0, //31-40% Количество циклов подъема в зависимости от веса груза
        val arrRestA5MW1: Int=0, //41-50% Количество циклов подъема в зависимости от веса груза
        val arrRestA5MW2: Int=0, //41-50% Количество циклов подъема в зависимости от веса груза
        val arrRestA6MW1: Int=0, //51-60% Количество циклов подъема в зависимости от веса груза
        val arrRestA6MW2: Int=0, //51-60% Количество циклов подъема в зависимости от веса груза
        val arrRestA7MW1: Int=0, //61-70% Количество циклов подъема в зависимости от веса груза
        val arrRestA7MW2: Int=0, //61-70% Количество циклов подъема в зависимости от веса груза
        val arrRestA8MW1: Int=0, //71-80% Количество циклов подъема в зависимости от веса груза
        val arrRestA8MW2: Int=0, //71-80% Количество циклов подъема в зависимости от веса груза
        val arrRestA9MW1: Int=0, //81-90% Количество циклов подъема в зависимости от веса груза
        val arrRestA9MW2: Int=0, //81-90% Количество циклов подъема в зависимости от веса груза
        val arrRestA10MW1: Int=0, //91-100% Количество циклов подъема в зависимости от веса груза
        val arrRestA10MW2: Int=0, //91-100% Количество циклов подъема в зависимости от веса груза
        val arrRestA11MW1: Int=0, //>101% Количество циклов подъема в зависимости от веса груза
        val arrRestA11MW2: Int=0, //>101% Количество циклов подъема в зависимости от веса груза
        val rCycleHoistMW1: Int=0, //Рабочие циклы подъема
        val rCycleHoistMW2: Int=0, //Рабочие циклы подъема
        val rCycleSlewMW1: Int=0, //Рабочие циклы поворота
        val rCycleSlewMW2: Int=0, //Рабочие циклы поворота
        val rCycleTrolleyMW1: Int=0, //Рабочие циклы тележки
        val rCycleTrolleyMW2: Int=0, //Рабочие циклы тележки
        val rCycleCraneMW1: Int=0, //Рабочие циклы хода крана
        val rCycleCraneMW2: Int=0, //Рабочие циклы хода крана
        val rCycleHoleCraneMW1: Int=0, //Рабочие циклы крана в целом
        val rCycleHoleCraneMW2: Int=0 //Рабочие циклы крана в целом
    )

    data class SavingAndLoadingSettings(
        val hmiReadSDcardStatus: Int=0, //Статус SD-карты
        val hmiReadVarSaveStatus: Int=0, //Статус сохранения VAR-файла 0-Ожидание, 1- Завершено, 2- В процессе, 4-Ошибка.
        val hmiReadVarSaveProcess: Float=0f, //Процес выполнения сохранения 0-100%
        val hmiReadVarReadStatus: Int=0, //Статус чтения VAR-файла 0-Ожидание, 1- Завершено, 2- В процессе, 4-Ошибка.
        val hmiReadVarReadProcess: Float=0f, //Процес выполнения чтения 0-100%
        val hmiReadVarSize: Float=0f, //Объем VAR-файла
    )



    // Сохранить VAR-файл в память ПЛК
    fun onSetSaveVarFile() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Команда на сохранение параметров СБКБ в VarFile
                modbusRepository.writeRegister(65001, 1)
                delay(200)
                modbusRepository.writeRegister(65001, 0)
            } catch (e: Exception) {
            }
        }
    }
    // Считать VAR-файл
    fun onSetReadVarFile() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Команда на считывание параметров СБКБ из VarFile
                modbusRepository.writeRegister(65002, 1)
                delay(200)
                modbusRepository.writeRegister(65002, 0)
            } catch (e: Exception) {
            }
        }
    }
    // Считать объем VAR-файла
    fun onSetReadSizeVarFile() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Команда на считывание параметров СБКБ из VarFile
                modbusRepository.writeRegister(65003, 1)
                delay(200)
                modbusRepository.writeRegister(65003, 0)
            } catch (e: Exception) {
            }
        }
    }
    // Отмена записи VAR-файла
    fun onSetSaveAbortVarFile() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Команда на считывание параметров СБКБ из VarFile
                modbusRepository.writeRegister(65004, 1)
                delay(200)
                modbusRepository.writeRegister(65004, 0)
            } catch (e: Exception) {
            }
        }
    }
    // Отмена чтения VAR-файла
    fun onSetReadAbortVarFile() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Команда на считывание параметров СБКБ из VarFile
                modbusRepository.writeRegister(65005, 1)
                delay(200)
                modbusRepository.writeRegister(65005, 0)
            } catch (e: Exception) {
            }
        }
    }
    // Записать VAR-файл на SD-карту
    fun onSetSaveVarFileToSD() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Команда на считывание параметров СБКБ из VarFile
                modbusRepository.writeRegister(65007, 1)
                delay(200)
                modbusRepository.writeRegister(65007, 0)
            } catch (e: Exception) {
            }
        }
    }

    // Записать файл регистратора параметров работы крана на SD-карту
    fun onSetSaveRPFileToSD() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Команда на считывание параметров СБКБ из VarFile
                modbusRepository.writeRegister(65006, 1)
                delay(200)
                modbusRepository.writeRegister(65006, 0)
            } catch (e: Exception) {
            }
        }
    }

    // Очистка при уничтожении ViewModel
    override fun onCleared() {
        super.onCleared()
        Log.d("ParameterLoggerVM", "ViewModel cleared")
        // Деактивируем конфигурацию при уничтожении ViewModel
        modbusRepository.setActiveUiConfiguration(null)
    }
}
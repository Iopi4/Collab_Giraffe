package com.example.giraffenew.navigate

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.DrawerState
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.giraffenew.accident_and_warning_log.AccidentWarningLogScreen
import com.example.giraffenew.coordinate_protection.prezentation.CoordinateProtectionScreen
import com.example.giraffenew.diagnostics.prezentation.DiagnosticsScreen
import com.example.giraffenew.ui.theme.Burgundy_violet
import com.example.giraffenew.ui.theme.Orange
import com.example.giraffenew.ui.theme.white
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import com.example.giraffenew.home.presentation.HomeScreen
import com.example.giraffenew.initial_setup.presentation.InitialSetupScreen
import com.example.giraffenew.login.presentation.LoginScreen
import com.example.giraffenew.navigate.presentation.TopBarViewModel
import com.example.giraffenew.parameter_logger.presentation.ParameterLoggerScreen
import com.example.giraffenew.service_menu.presentation.ServiceMenuScreen
import com.example.giraffenew.setting_load_capacity.presentation.SettingLoadCapacityScreen
import com.example.giraffenew.setting_rotation.presentation.SettingRotationScreen
import com.example.giraffenew.setting_sensors.presentation.SettingSensorsScreen
import com.example.giraffenew.technical_maintenance.presentation.TechnicalMaintenanceScreen
import com.example.giraffenew.R
import com.example.giraffenew.android_error_logger.presentation.screen.ExceptionsScreen
import com.example.giraffenew.core.ui_kit.composable.lamp.BasicLampCloudDone
import com.example.giraffenew.core.ui_kit.composable.lamp.BasicLampEthernetDone
import com.example.giraffenew.home.ui.button.ButtonIconAndroid


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SampleAppNavGraph(
    modifier: Modifier = Modifier,
    onKioskModeToggle: () -> Unit = {},
    isKioskModeEnabled: Boolean = false,
    navController: NavHostController = rememberNavController(),
    coroutineScope: CoroutineScope = rememberCoroutineScope(),
    drawerState: DrawerState = rememberDrawerState(initialValue = DrawerValue.Closed),

) {
    val topBarViewModel: TopBarViewModel = hiltViewModel()
    val currentNavBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = currentNavBackStackEntry?.destination?.route ?: AllDestinations.NAVIGATE_TO_HOME
    val navigationActions = remember (navController) {
        AppNavigationActions(navController) }

    val buildMode = topBarViewModel.buildMode.value
    val serviceMode = topBarViewModel.serviceMode.value
    val montageMode = topBarViewModel.montageMode.value

    // Формируем список активных режимов
    val activeModes = buildList {
        if (buildMode == 1) add(stringResource(R.string.LoginScreen_Text_Reset_Build_Mode))
        if (serviceMode == 1) add(stringResource(R.string.LoginScreen_Text_Reset_Service_Mode))
        if (montageMode == 1) add(stringResource(R.string.LoginScreen_Text_Reset_Montage_Mode))
    }
    // Объединяем через запятую или используем пустую строку если нет активных режимов
    val mode = if (activeModes.isNotEmpty()) {
        activeModes.joinToString()
    } else {
        "РАБОТА" // Пустая строка вместо null
    }
    val modeColor = when {
        buildMode == 1 -> colorResource(R.color.Red)
        serviceMode == 1 -> colorResource(R.color.Red)
        montageMode == 1 -> colorResource(R.color.Red)
    else -> colorResource(R.color.Silver) }


    // Собираем статус подключения к облаку
    val cloudConnectionStatus by topBarViewModel.cloudConnectionStatus.collectAsState()

    // Собираем статус подключения к Modbus
    val modbusConnectionStatus by topBarViewModel.modbusConnectionStatus.collectAsState()

    ModalNavigationDrawer(drawerContent = {
        AppDrawer(
            route = currentRoute,
            navigateToHome = { navigationActions.navigateToHome() },
            navigateToSettings = { navigationActions.navigateTo_InitialSetup() },
            navigateToSettingLoadCapacity = { navigationActions.navigateTo_SettingLoadCapacity() },
            navigateToSettingSensor = { navigationActions.navigateTo_SettingSensors() },
            navigateToCoordinateProtection = { navigationActions.navigateTo_CoordinateProtection() },
            navigateToSettingRotation = { navigationActions.navigateTo_SettingRotation() },
            navigateToServiceMenu = { navigationActions.navigateTo_ServiceMenu() },
            navigateToDiagnostics = { navigationActions.navigateTo_Diagnostics() },
            navigateToParameterLogger = { navigationActions.navigateTo_ParameterLogger() },
            navigateToTechnicalMaintenance = { navigationActions.navigateTo_TechnicalMaintenance() },
            navigateToAccidentWarninglog = { navigationActions.navigateTo_AccidentAndWarningLog() },
            navigateToLogin = { navigationActions.navigateTo_Login() },
            //navigateToModbusTools = {navigationActions.navigateTo_ModbusTools() },
            navigateToExceptionLog = {navigationActions.navigateTo_Exceptions() },
            closeDrawer = { coroutineScope.launch { drawerState.close() } },
            modifier = Modifier,
            buildMode = topBarViewModel.buildMode.value, // Передаем значение buildMode
            serviceMode = topBarViewModel.serviceMode.value,
        )
    }, drawerState = drawerState) {
        val boxTopBarText = Modifier
            .padding(top = 5.dp, start = 16.dp)
            .clip(shape = RoundedCornerShape(1.dp))

        Scaffold(

            topBar = {
                Row (modifier = Modifier
                    .fillMaxHeight(0.08f)
                    .background(color = Orange)) {
                    Box(modifier = Modifier.weight(4f)) {

//Область отображения типа крана и кнопки меню навигации
                        Column (modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.SpaceBetween ) {
//Область отображения типа крана
                            Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceBetween) {

                                Box (boxTopBarText) {TopBarText(topBarViewModel.currentModelCrane.value) }
                                Box (boxTopBarText) {TopBarText(topBarViewModel.currentPulleyBlock.value) }
                                Box (boxTopBarText) {TopBarText(topBarViewModel.currentLoadCapacity.value) }

                                // Добавляем кнопку управления kiosk режимом

                            }

//Область отображения кнопки меню навигации

                            Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceBetween) {
                                Box (modifier = Modifier.weight(7f)){
                                TopAppBar(title = {
                                    Text(
                                        text = currentRoute, color = white) },
                                    modifier = Modifier.fillMaxWidth(),
                                    navigationIcon = {
                                        IconButton(onClick = {
                                            coroutineScope.launch {
                                                drawerState.open() } },
                                        content = {
                                            Icon(imageVector = Icons.Default.Menu, contentDescription = null, tint = white) })
                                                     },
                                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Orange))
                                }
                                val myBoxModifier = Modifier
                                    .clip(shape = RoundedCornerShape(5.dp))
                                    .background(colorResource(R.color.black))
                                    .fillMaxWidth()
                                    .border(
                                        width = 2.dp,
                                        color = modeColor,
                                        shape = RoundedCornerShape(5.dp)
                                    )
                                Box (myBoxModifier.weight(2f, )
                                ){
                                    Text(modifier = modifier
                                        .fillMaxWidth()
                                        .padding(
                                            start = 1.dp,
                                            end = 1.dp,
                                            top = 5.dp,
                                            bottom = 5.dp
                                        ),
                                        text = mode,
                                        fontSize = 18.sp, fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center, color = modeColor
                                    )
                                }
                            }

                        }
                    }
//Область отобтражения даты и времени
                    Box(modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            Row(modifier = Modifier, horizontalArrangement = Arrangement.SpaceBetween) {
                                BasicLampCloudDone(
                                    isStatusCloud = cloudConnectionStatus
                                )
                                BasicLampEthernetDone(
                                    isStatusEthernet = modbusConnectionStatus
                                )
                                ButtonIconAndroid(
                                    onClick = onKioskModeToggle,
                                    isKioskModeEnabled = isKioskModeEnabled
                                )
                            }
                            TopBarTextDateTime(topBarViewModel.currentTime.value)
                            TopBarTextDateTime(topBarViewModel.currentDate.value)
                        }
                    }
                }

            }, modifier = Modifier

        ) {
            NavHost(
                //При вызове в NavHost передается объект NavHostController, компонент, который будет служить
                // начальным экраном/начальным пунктом назначения, и граф навигации (navigation graph):
                navController = navController,
                startDestination = AllDestinations.NAVIGATE_TO_HOME, modifier = modifier.padding(it)
                    //startDestination = HOME_SCREEN_ROUTE
                ) {

                composable (AllDestinations.NAVIGATE_TO_HOME) {
                    HomeScreen()
                }

                composable(AllDestinations.NAVIGATE_INITIAL_SETUP) {
                    InitialSetupScreen()
                }

                composable(AllDestinations.NAVIGATE_SETTING_LOAD_CAPASITY) {
                    SettingLoadCapacityScreen()
                }

                composable(AllDestinations.NAVIGATE_SETTING_SENSORS) {
                    SettingSensorsScreen()
                }

                composable(AllDestinations.NAVIGATE_COORDINATE_PROTECTION) {
                    CoordinateProtectionScreen()
                }

                composable(AllDestinations.NAVIGATE_SETTING_ROTATION) {
                    SettingRotationScreen()
                }

                composable(AllDestinations.NAVIGATE_SERVICE_MENU) {
                    ServiceMenuScreen(
                        onKioskModeToggle = onKioskModeToggle,
                        isKioskModeEnabled = isKioskModeEnabled
                    )
                }

                composable(AllDestinations.NAVIGATE_DIAGNOSTICS) {
                    DiagnosticsScreen()
                }

                composable(AllDestinations.NAVIGATE_PARAMETER_LOGGER) {
                    ParameterLoggerScreen(
                    )
                }

                composable(AllDestinations.NAVIGATE_TECHNICAL_MAINTENANCE) {
                    TechnicalMaintenanceScreen()
                }

                composable(AllDestinations.NAVIGATE_ACCIDENT_AND_WARNING_LOG) {
                    AccidentWarningLogScreen()
                }

                composable(AllDestinations.NAVIGATE_LOGIN) {
                    LoginScreen()
                }

                composable(AllDestinations.NAVIGATE_EXCEPTION) {
                    ExceptionsScreen()
                }

                //composable(AllDestinations.NAVIGATE_MODBUS_TOOLS) {
                    //ModbusToolsScreen()
                //}

            }
        }
    }
}



@Composable
//Создадим функцию для свойств текста TopAppBar (Верхняя часть экрана - Информация о кране)
fun TopBarText (text:String, modifier:Modifier=Modifier){
    Text(text, modifier, fontSize = 18.sp, textAlign = TextAlign.Start, color = Burgundy_violet, fontWeight = FontWeight.Bold) }

@Composable
//Создадим функцию для свойств текста TopAppBar (Верхняя часть экрана - Дата и время)
fun TopBarTextDateTime (text:String, modifier:Modifier=Modifier){
    Text(text, modifier.padding(1.dp), fontSize = 18.sp, textAlign = TextAlign.Center, color = Burgundy_violet, fontWeight = FontWeight.Bold) }
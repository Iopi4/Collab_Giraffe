package com.example.giraffenew.initial_setup.presentation

import android.util.Log
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.giraffenew.data.repositories.ModbusRepository
import com.example.giraffenew.initial_setup.data.CraneRepository
import com.example.giraffenew.initial_setup.data.TimeZoneRepository
import com.example.giraffenew.initial_setup.domain.CraneEntity
import com.example.giraffenew.initial_setup.domain.TimeZoneEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class InitialSetupViewModel
@Inject constructor(
    private val modbusRepository: ModbusRepository,
    private var craneRepository: CraneRepository, // Внедряем через Hilt
    private var timeZoneRepository: TimeZoneRepository, // Внедряем через Hilt
): ViewModel(){

    // Переменные для ввода даты и времени
    private val _setValueHour = mutableStateOf("")
    val setValueHour: State<String> = _setValueHour

    private val _setValueMinute = mutableStateOf("")
    val setValueMinute: State<String> = _setValueMinute

    private val _setValueDay = mutableStateOf("")
    val setValueDay: State<String> = _setValueDay

    private val _setValueMonth = mutableStateOf("")
    val setValueMonth: State<String> = _setValueMonth

    private val _setValueYear = mutableStateOf("")
    val setValueYear: State<String> = _setValueYear

    // Job для управления подписками
    private var loadCranesJob: Job? = null
    private var loadTimeZonesJob: Job? = null

    // Переменные выбора часового пояса
    private val _selectedTimeZone = mutableStateOf<TimeZoneEntity?>(null)
    val selectedTimeZone: State<TimeZoneEntity?> = _selectedTimeZone

    private val _showTimeZoneDialog = mutableStateOf(false)
    val showTimeZoneDialog: State<Boolean> = _showTimeZoneDialog

    private val _selectedTimeZoneUTC = mutableStateOf<Int?>(null)
    val selectedTimeZoneUTC: State<Int?> = _selectedTimeZoneUTC

    private val _timeZonesList = mutableStateListOf<TimeZoneEntity>()
    val timeZonesList: List<TimeZoneEntity> = _timeZonesList

// Переменные выбора модели крана

    // Переменные выбора модели крана
    private val _selectedCrane = mutableStateOf<CraneEntity?>(null)
    val selectedCrane: State<CraneEntity?> = _selectedCrane

    private val _showCraneDialog = mutableStateOf(false)
    val showCraneDialog: State<Boolean> = _showCraneDialog

    private val _selectedCraneId = mutableStateOf<Int?>(null)
    val selectedCraneId: State<Int?> = _selectedCraneId

    private val _cranesList = mutableStateListOf<CraneEntity>()
    val cranesList: List<CraneEntity> = _cranesList

// Переменные выбора модели крана



    private val _setNumberCrane = mutableStateOf("")
    val setValueNumberCrane: State<String> = _setNumberCrane

    private val _setNumberSBKB = mutableStateOf("")
    val setValueNumberSBKB: State<String> = _setNumberSBKB

    private val _setValueDayCrane = mutableStateOf("")
    val setValueDayCrane: State<String> = _setValueDayCrane

    private val _setValueMonthCrane = mutableStateOf("")
    val setValueMonthCrane: State<String> = _setValueMonthCrane

    private val _setValueYearCrane = mutableStateOf("")
    val setValueYearCrane: State<String> = _setValueYearCrane

    private val _setValueDayRTN = mutableStateOf("")
    val setValueDayRTN: State<String> = _setValueDayRTN

    private val _setValueMonthRTN = mutableStateOf("")
    val setValueMonthRTN: State<String> = _setValueMonthRTN

    private val _setValueYearRTN = mutableStateOf("")
    val setValueYearRTN: State<String> = _setValueYearRTN

    private val _setValueDaySBKB = mutableStateOf("")
    val setValueDaySBKB: State<String> = _setValueDaySBKB

    private val _setValueMonthSBKB = mutableStateOf("")
    val setValueMonthSBKB: State<String> = _setValueMonthSBKB

    private val _setValueYearSBKB = mutableStateOf("")
    val setValueYearSBKB: State<String> = _setValueYearSBKB


    private val _errorMessage = mutableStateOf<String?>(null)
    val errorMessage: State<String?> = _errorMessage

    private val _errorMessageCrane = mutableStateOf<String?>(null)
    val errorMessageCrane: State<String?> = _errorMessageCrane

    private val _errorMessageRTN = mutableStateOf<String?>(null)
    val errorMessageRTN: State<String?> = _errorMessageRTN

    private val _errorMessageSBKB = mutableStateOf<String?>(null)
    val errorMessageSBKB: State<String?> = _errorMessageSBKB

    private val _logMessageDateTime = mutableStateOf<String?>(null)
    val logMessageDateTime: State<String?> = _logMessageDateTime

    private val _logMessageCrane = mutableStateOf<String?>(null)
    val logMessageCrane: State<String?> = _logMessageCrane

    private val _logMessageRTN = mutableStateOf<String?>(null)
    val logMessageRTN: State<String?> = _logMessageRTN

    private val _logMessageSBKB = mutableStateOf<String?>(null)
    val logMessageSBKB: State<String?> = _logMessageSBKB

    //Подписка на актуальные модели кранов и часовые пояса из баз данных
    init {
        //Загрузка базы данных модели кранов
        loadAllCranes()
        //Загрузка базы данных часовых поясов
        loadAllTimeZones()
    }

    private fun validateAndConvert(value: String, min: Int, max: Int): Int {
        val intValue = value.toIntOrNull() ?: throw NumberFormatException("Некорректное число")
        if (intValue !in min..max) throw IllegalArgumentException("Значение вне диапазона")
        return intValue
    }

    private fun validateAndConvertFloat(value: String, min: Float, max: Float): Int {
        val floatValue = value.toFloatOrNull() ?: throw NumberFormatException("Некорректное число")
        if (floatValue < min || floatValue > max) throw IllegalArgumentException("Значение вне диапазона")
        return (floatValue * 1000).toInt()
    }


    // Запись даты и времени в ПЛК
    fun onSetDateTime() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (!isActive) return@launch // Проверка активности ViewModel
                // Валидация и преобразование значений
                val hour = validateAndConvert(_setValueHour.value, 0, 23)
                val minute = validateAndConvert(_setValueMinute.value, 0, 59)
                val day = validateAndConvert(_setValueDay.value, 1, 31)
                val month = validateAndConvert(_setValueMonth.value, 1, 12)
                val year = validateAndConvert(_setValueYear.value, 2006, 2099)
                // Запись в регистры
                Log.d("InitialSetupViewModel", "Writing registers...")
                modbusRepository.writeRegister(60004, hour)
                modbusRepository.writeRegister(60005, minute)
                modbusRepository.writeRegister(60003, day)
                modbusRepository.writeRegister(60002, month)
                modbusRepository.writeRegister(60001, year)

                // Активация записи
                modbusRepository.writeRegister(60000, 1)
                delay(1000)
                modbusRepository.writeRegister(60000, 0)
                _errorMessage.value = null
                _logMessageDateTime.value = "Сохранено"
                // Логирование
                Log.i("InitialSetupVM", "Registers written successfully")
            } catch (e: Exception) {
                Log.e("InitialSetupVM", "Запись не удалась: ${e.message}", e)
                _errorMessage.value = "${e.message}"
                _logMessageDateTime.value = null
            }
        }
    }
    private fun loadAllCranes() {
        // Отменяем предыдущую загрузку
        loadCranesJob?.cancel()

        loadCranesJob = viewModelScope.launch {
            try {
                val cranes = craneRepository.getAllCranes()
                _cranesList.clear()
                _cranesList.addAll(cranes)
            } catch (e: Exception) {
                _errorMessageCrane.value = "Ошибка загрузки списка кранов: ${e.message}"
            }
        }
    }

    fun openCraneDialog() {
        _showCraneDialog.value = true
    }

    fun closeCraneDialog() {
        _showCraneDialog.value = false
    }

    fun selectCrane(crane: CraneEntity) {
        _selectedCrane.value = crane
        _selectedCraneId.value = crane.craneID
        closeCraneDialog()
    }

    private fun loadAllTimeZones() {
        // Отменяем предыдущую загрузку
        loadTimeZonesJob?.cancel()

        loadTimeZonesJob = viewModelScope.launch {
            try {
                val timeZones = timeZoneRepository.getAllTimeZone()
                _timeZonesList.clear()
                _timeZonesList.addAll(timeZones)
            } catch (e: Exception) {
                _errorMessageCrane.value = "Ошибка загрузки списка кранов: ${e.message}"
            }
        }
    }
    fun openTimeZoneDialog() {
        _showTimeZoneDialog.value = true
    }

    fun closeTimeZoneDialog() {
        _showTimeZoneDialog.value = false
    }

    fun selectTimeZone(timeZone: TimeZoneEntity) {
        _selectedTimeZone.value = timeZone
        _selectedTimeZoneUTC.value = timeZone.timeZoneUTC
        closeTimeZoneDialog()
    }


    // Запись часового пояса
    fun onSetTimeZone(timeZoneUTC: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Запись в регистр часового пояса (timeZoneUTC)
                modbusRepository.writeRegister(60007, timeZoneUTC)
                _errorMessage.value = null
                _logMessageDateTime.value = "Сохранено"
            } catch (e: Exception) {
                _errorMessage.value = "${e.message}"
                _logMessageDateTime.value = null
            }
        }
    }

    // Запись даты ввода крана в эксплуатацию
    fun onSetDateCrane() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (!isActive) return@launch // Проверка активности ViewModel
                // Валидация и преобразование значений
                val day = validateAndConvert(_setValueDayCrane.value, 1, 31)
                val month = validateAndConvert(_setValueMonthCrane.value, 1, 12)
                val year = validateAndConvert(_setValueYearCrane.value, 2006, 2099)

                // Запись в регистры даты ввода крана в эксплуатацию
                modbusRepository.writeRegister(63554, day)
                modbusRepository.writeRegister(63555, month)
                modbusRepository.writeRegister(63556, year)

                _errorMessageCrane.value = null
                _logMessageCrane.value = "Сохранено"
            } catch (e: Exception) {
                _errorMessageCrane.value = "${e.message}"
                _logMessageCrane.value = null
            }
        }
    }
    // Запись даты регистрации крана в Ростехнадзоре
    fun onSetDateRTN() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Валидация и преобразование значений
                val day = validateAndConvert(_setValueDayRTN.value, 1, 31)
                val month = validateAndConvert(_setValueMonthRTN.value, 1, 12)
                val year = validateAndConvert(_setValueYearRTN.value, 2006, 2099)

                // Запись в регистры даты регистрации крана в Ростехнадзоре
                modbusRepository.writeRegister(63551, day)
                modbusRepository.writeRegister(63552, month)
                modbusRepository.writeRegister(63553, year)

                _errorMessageRTN.value = null
                _logMessageRTN.value = "Сохранено"
            } catch (e: Exception) {
                _errorMessageRTN.value = "${e.message}"
                _logMessageRTN.value = null
            }
        }
    }

    // Запись даты установки СБКБ на кран
    fun onSetDateSBKB() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Валидация и преобразование значений
                val day = validateAndConvert(_setValueDaySBKB.value, 1, 31)
                val month = validateAndConvert(_setValueMonthSBKB.value, 1, 12)
                val year = validateAndConvert(_setValueYearSBKB.value, 2006, 2099)

                // Запись в регистры даты установки СБКБ на кран
                modbusRepository.writeRegister(63557, day)
                modbusRepository.writeRegister(63558, month)
                modbusRepository.writeRegister(63559, year)

                _errorMessageSBKB.value = null
                _logMessageSBKB.value = "Сохранено"
            } catch (e: Exception) {
                _errorMessageSBKB.value = "${e.message}"
                _logMessageSBKB.value = null
            }
        }
    }

    // Запись модели крана
    fun onSetModelCrane(craneID: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Запись в регистры модель крана (craneID)
                modbusRepository.writeRegister(63501, craneID)
                _errorMessageCrane.value = null
                _logMessageCrane.value = "Сохранено"
            } catch (e: Exception) {
                _errorMessageCrane.value = "${e.message}"
                _logMessageCrane.value = null
            }
        }
    }

    // Запись заводского номера крана
    fun onSetNumberCrane() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val number = validateAndConvert(_setNumberCrane.value, 0, 65535)
                // Запись в регистры номер крана
                modbusRepository.writeRegister(63502, number)
                _errorMessageCrane.value = null
                _logMessageCrane.value = "Сохранено"
            } catch (e: Exception) {
                _errorMessageCrane.value = "${e.message}"
                _logMessageCrane.value = null
            }
        }
    }

    // Запись заводского номера СБКБ
    fun onSetNumberSBKB() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val number = validateAndConvert(_setNumberSBKB.value, 0, 65535)
                // Запись в регистры модель крана
                modbusRepository.writeRegister(63510, number)
                // Сброс состояний

                _errorMessageSBKB.value = null
                _logMessageSBKB.value = "Сохранено"
            } catch (e: Exception) {
                _errorMessageSBKB.value = "${e.message}"
                _logMessageSBKB.value = null
            }
        }
    }




    // Обновления для UI
    fun updateHour(value: String) {
        if (value.isEmpty() || value.toIntOrNull() != null) {
            _setValueHour.value = value
        }
    }

    fun updateMinute(value: String) {
        if (value.isEmpty() || value.toIntOrNull() != null) {
            _setValueMinute.value = value
        }
    }

    fun updateDay(value: String) {
        if (value.isEmpty() || value.toIntOrNull() != null) {
            _setValueDay.value = value
        }
    }

    fun updateMonth(value: String) {
        if (value.isEmpty() || value.toIntOrNull() != null) {
            _setValueMonth.value = value
        }
    }

    fun updateYear(value: String) {
        if (value.isEmpty() || value.toIntOrNull() != null) {
            _setValueYear.value = value
        }
    }

    fun updateDayCrane(value: String) {
        if (value.isEmpty() || value.toIntOrNull() != null) {
            _setValueDayCrane.value = value
        }
    }

    fun updateMonthCrane(value: String) {
        if (value.isEmpty() || value.toIntOrNull() != null) {
            _setValueMonthCrane.value = value
        }
    }

    fun updateYearCrane(value: String) {
        if (value.isEmpty() || value.toIntOrNull() != null) {
            _setValueYearCrane.value = value
        }
    }

    fun updateDayRTN(value: String) {
        if (value.isEmpty() || value.toIntOrNull() != null) {
            _setValueDayRTN.value = value
        }
    }

    fun updateMonthRTN(value: String) {
        if (value.isEmpty() || value.toIntOrNull() != null) {
            _setValueMonthRTN.value = value
        }
    }

    fun updateYearRTN(value: String) {
        if (value.isEmpty() || value.toIntOrNull() != null) {
            _setValueYearRTN.value = value
        }
    }

    fun updateDaySBKB(value: String) {
        if (value.isEmpty() || value.toIntOrNull() != null) {
            _setValueDaySBKB.value = value
        }
    }

    fun updateMonthSBKB(value: String) {
        if (value.isEmpty() || value.toIntOrNull() != null) {
            _setValueMonthSBKB.value = value
        }
    }

    fun updateYearSBKB(value: String) {
        if (value.isEmpty() || value.toIntOrNull() != null) {
            _setValueYearSBKB.value = value
        }
    }

    fun updateNumberCrane(value: String) {
        if (value.isEmpty() || value.toIntOrNull() != null) {
            _setNumberCrane.value = value
        }
    }

    fun updateValueNumberSBKB(value: String) {
        if (value.isEmpty() || value.toIntOrNull() != null) {
            _setNumberSBKB.value = value
        }
    }

    // Очистка при уничтожении ViewModel
    override fun onCleared() {
        super.onCleared()

        // Отменяем все подписки
        loadCranesJob?.cancel()
        loadTimeZonesJob?.cancel()

        Log.d("InitialSetupVM", "ViewModel cleared")
        modbusRepository.setActiveUiConfiguration(null)
    }
}
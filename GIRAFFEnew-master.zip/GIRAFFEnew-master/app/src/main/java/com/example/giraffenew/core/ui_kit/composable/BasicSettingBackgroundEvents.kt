package com.example.giraffenew.core.ui_kit.composable

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.tooling.preview.Preview
import com.example.giraffenew.R
import com.example.giraffenew.ui.theme.GIRAFFEnewTheme

@Composable
fun BasicSettingBackgroundEvents (){
    Box(
        modifier = Modifier
            .padding()
            .fillMaxSize()
            .background(colorResource(R.color.Silver)),
        contentAlignment = Alignment.TopStart
    ) {
    }
}

@Preview
@Composable
fun BasicSettingBackgroundEventsPreview (
) {
    GIRAFFEnewTheme(dynamicColor = false) {
        BasicSettingBackgroundEvents()
    }
}